/*
 * Copyright (c) 2020 Raspberry Pi (Trading) Ltd.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef _PICO_AUDIO_PWM_H
#define _PICO_AUDIO_PWM_H

#include "pico/audio.h"

/** \file audio_pwm.h
 *  \defgroup pico_audio_pwm pico_audio_pwm
 *  PWM audio output using the PIO
 *
 * This library uses the \ref hardware_pio system to implement a PWM audio interface
 *
 * \todo Must be more we need to say here.
 * \todo certainly need an example
 *
 */

#ifdef __cplusplus
extern "C" {
#endif

#ifndef PICO_AUDIO_PWM_DMA_IRQ
#ifdef PICO_AUDIO_DMA_IRQ
#define PICO_AUDIO_PWM_DMA_IRQ PICO_AUDIO_DMA_IRQ
#else
#define PICO_AUDIO_PWM_DMA_IRQ 0
#endif
#endif

#ifndef PICO_AUDIO_PWM_PIO
#ifdef PICO_AUDIO_PIO
#define PICO_AUDIO_PWM_PIO PICO_AUDIO_PIO
#else
#define PICO_AUDIO_PWM_PIO 0
#endif
#endif

#if !(PICO_AUDIO_PWM_DMA_IRQ == 0 || PICO_AUDIO_PWM_DMA_IRQ == 1)
#error PICO_AUDIO_PWM_DMA_IRQ must be 0 or 1
#endif

#if !(PICO_AUDIO_PWM_PIO == 0 || PICO_AUDIO_PWM_PIO == 1)
#error PICO_AUDIO_PWM_PIO ust be 0 or 1
#endif

#ifndef PICO_AUDIO_PWM_MAX_CHANNELS
#ifdef PICO_AUDIO_MAX_CHANNELS
#define PICO_AUDIO_PWM_MAX_CHANNELS PICO_AUDIO_MAX_CHANNELS
#else
#define PICO_AUDIO_PWM_MAX_CHANNELS 2u
#endif
#endif

#ifndef PICO_AUDIO_PWM_BUFFERS_PER_CHANNEL
#ifdef PICO_AUDIO_BUFFERS_PER_CHANNEL
#define PICO_AUDIO_PWM_BUFFERS_PER_CHANNEL PICO_AUDIO_BUFFERS_PER_CHANNEL
#else
#define PICO_AUDIO_PWM_BUFFERS_PER_CHANNEL 3u
#endif
#endif

#ifndef PICO_AUDIO_PWM_BUFFER_SAMPLE_LENGTH
#ifdef PICO_AUDIO_BUFFER_SAMPLE_LENGTH
#define PICO_AUDIO_PWM_BUFFER_SAMPLE_LENGTH PICO_AUDIO_BUFFER_SAMPLE_LENGTH
#else
#define PICO_AUDIO_PWM_BUFFER_SAMPLE_LENGTH 576u
#endif
#endif

#ifndef PICO_AUDIO_PWM_SILENCE_BUFFER_SAMPLE_LENGTH
#ifdef PICO_AUDIO_PWM_SILENCE_BUFFER_SAMPLE_LENGTH
#define PICO_AUDIO_PWM_SILENCE_BUFFER_SAMPLE_LENGTH PICO_AUDIO_SILENCE_BUFFER_SAMPLE_LENGTH
#else
#define PICO_AUDIO_PWM_SILENCE_BUFFER_SAMPLE_LENGTH 256u
#endif
#endif

// Allow use of pico_audio driver without actually doing anything much
#ifndef PICO_AUDIO_PWM_NOOP
#ifdef PICO_AUDIO_NOOP
#define PICO_AUDIO_PWM_NOOP PICO_AUDIO_NOOP
#else
#define PICO_AUDIO_PWM_NOOP 0
#endif
#endif

#ifndef PICO_AUDIO_PWM_MONO_INPUT
#define PICO_AUDIO_PWM_MONO_INPUT 0
#endif
#ifndef PICO_AUDIO_PWM_MONO_OUTPUT
#define PICO_AUDIO_PWM_MONO_OUTPUT 0
#endif

#ifndef PICO_AUDIO_PWM_DATA_PIN
//#warning PICO_AUDIO_PWM_DATA_PIN should be defined when using AUDIO_PWM
#define PICO_AUDIO_PWM_DATA_PIN 28
#endif

// todo this needs to come from a build config
/** \brief Base configuration structure used when setting up
 * \ingroup pico_audio_pwm
 */
typedef struct audio_pwm_config {
    uint8_t data_pin;
    uint8_t dma_channel;
    uint8_t pio_sm;
} audio_pwm_config_t;

/** \brief Set up system to output PWM audio
 * \ingroup pico_audio_pwm
 *
 * \param intended_audio_format \todo
 * \param config The configuration to apply.
 */
const audio_format_t *audio_pwm_setup(const audio_format_t *intended_audio_format,
                                               const audio_pwm_config_t *config);


/** \brief \todo
 * \ingroup pico_audio_pwm
 *
 * \param producer
 * \param connection
 */
bool audio_pwm_connect_thru(audio_buffer_pool_t *producer, audio_connection_t *connection);


/** \brief \todo
 * \ingroup pico_audio_pwm
 *
 * \param producer
 *
 *  todo make a common version (or a macro) .. we don't want to pull in unnecessary code by default
 */
bool audio_pwm_connect(audio_buffer_pool_t *producer);


/** \brief \todo
 * \ingroup pico_audio_pwm
 *
 * \param producer
 */
bool audio_pwm_connect_s8(audio_buffer_pool_t *producer);

/** \brief \todo
 * \ingroup pico_audio_pwm
 *
 * \param producer
 * \param buffer_on_give
 * \param buffer_count
 * \param samples_per_buffer
 * \param connection
 * \return
 */
bool audio_pwm_connect_extra(audio_buffer_pool_t *producer, bool buffer_on_give, uint buffer_count,
                                 uint samples_per_buffer, audio_connection_t *connection);


/** \brief Set up system to output PWM audio
 * \ingroup pico_audio_pwm
 *
 * \param enable true to enable PWM audio, false to disable.
 */
void audio_pwm_set_enabled(bool enabled);

#ifdef __cplusplus
}
#endif

#endif //_AUDIO_PWM_H
